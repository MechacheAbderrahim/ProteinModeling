# Protein Modeling Pipeline

This repository contains three scripts to generate different protein representations from a PDB file.

## Scripts

### EDTSurf.py
Generates a 3D surface mesh (PLY) from a PDB file using EDTSurf (Linux version).  
Default EDTSurf parameters are used. For more information, refer to the official EDTSurf website:  
https://zhanggroup.org/EDTSurf/

Example usage: `python EDTSurf.py -i example.pdb`

### surface_based.py
From a PLY file, this script creates two surface-based representations:  
- A point cloud  
- A surface graph  

The outputs are saved as PyTorch tensors (.pt).

Example usage: `python surface_based.py -i example.ply -f 0.1 -p 1024`  
`-f` is the reduction factor, `-p` is the number of points to generate for the point cloud.

### structure_graphs.py
Generates a structure-based graph from a PDB file and its corresponding point cloud (.pt).  
The `example.ply` file must be available in `./data/ply`.

Example usage: `python structure_graphs.py -i example.pdb`

## Notes
- EDTSurf binary is located in the `/bin` folder and must be executable on Linux.
- A sample PDB file is available in `./data/pdb` for testing.